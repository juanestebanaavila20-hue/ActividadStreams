/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ucompensar.codigo;

import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        
        List<Estudiante> estudiantes = Arrays.asList(
            new Estudiante("Ana Perez", "Ingenieria de Sistemas", 4.5),
            new Estudiante("Carlos Gomez", "Administracion", 2.8),
            new Estudiante("Maria Rodriguez", "Ingenieria de Sistemas", 3.9),
            new Estudiante("Juan Lopez", "Derecho", 4.8),
            new Estudiante("Lucia Martinez", "Administracion", 3.0),
            new Estudiante("David Torres", "Ingenieria de Sistemas", 2.2),
            new Estudiante("Sofia Ramirez", "Derecho", 4.1),
            new Estudiante("Mateo Herrera", "Administracion", 4.6),
            new Estudiante("Valentina Castro", "Derecho", 1.9),
            new Estudiante("Andres Morales", "Ingenieria de Sistemas", 3.5)
        );

        System.out.println(" LISTA ORIGINAL DE ESTUDIANTES ");
        estudiantes.forEach(System.out::println);

        List<Estudiante> aprobados = estudiantes.stream()
                .filter(e -> e.getNota() >= 3.0)
                .collect(Collectors.toList());

        System.out.println("\n ESTUDIANTES APROBADOS ");
        aprobados.forEach(System.out::println);

        List<Estudiante> ordenados = estudiantes.stream()
                .sorted(Comparator.comparing(Estudiante::getNota).reversed()
                                  .thenComparing(Estudiante::getNombre))
                .collect(Collectors.toList());

        System.out.println("\n ORDENADOS ");
        ordenados.forEach(System.out::println);

        List<Estudiante> tresMejores = estudiantes.stream()
                .sorted(Comparator.comparing(Estudiante::getNota).reversed())
                .limit(3)
                .collect(Collectors.toList());

        System.out.println("\n LOS TRES MEJORES ESTUDIANTES ");
        tresMejores.forEach(System.out::println);

        double promedioGeneral = estudiantes.stream()
                .mapToDouble(Estudiante::getNota)
                .average()
                .orElse(0.0);

        System.out.println("\n PROMEDIO GENERAL ");
        System.out.println("Promedio: " + promedioGeneral);

        Map<String, Double> promedioPorPrograma = estudiantes.stream()
                .collect(Collectors.groupingBy(
                        Estudiante::getPrograma,
                        Collectors.averagingDouble(Estudiante::getNota)
                ));

        System.out.println("\n PROMEDIO POR PROGRAMA ");
        promedioPorPrograma.forEach((programa, promedio) -> 
            System.out.println("Programa: " + programa + " -> Promedio: " + promedio)
        );

        Map<Boolean, List<Estudiante>> particionAprobados = estudiantes.stream()
                .collect(Collectors.partitioningBy(e -> e.getNota() >= 3.0));

        System.out.println("\n APROBADOS Y REPROBADOS ");
        particionAprobados.forEach((esAprobado, lista) -> {
            String estado = esAprobado ? "Aprobados" : "Reprobados";
            System.out.println("-- " + estado + " --");
            lista.forEach(e -> System.out.println("   " + e));
        });
    }
}