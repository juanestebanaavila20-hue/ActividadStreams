/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ucompensar.codigo;

public class Estudiante {
    private String nombre;
    private String programa;
    private double nota;

    public Estudiante(String nombre, String programa, double nota) {
        this.nombre = nombre;
        this.programa = programa;
        this.nota = nota;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPrograma() {
        return programa;
    }

    public double getNota() {
        return nota;
    }

    @Override
    public String toString() {
        return String.format("Estudiante{nombre='%s', programa='%s', nota=%.2f}", nombre, programa, nota);
    }
}